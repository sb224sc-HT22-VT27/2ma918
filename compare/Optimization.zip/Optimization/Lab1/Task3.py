import numpy as np
from scipy.optimize import linprog

profitA = 700
profitB = 1000
profitC = 1350

stage1A = 3
stage1B = 5
stage1C = 7
totTime1 = 3900

stage2A = 1
stage2B = 3
stage2C = 4
totTime2 = 2100

stage3ABC = 2
totTime3 = 2200

# Dual problem
A = np.matrix([[stage1A, stage1B], [stage2A, stage2B], [stage3ABC, stage3ABC]])
b = np.matrix([[totTime1], [totTime2], [totTime3]])
c = np.matrix([[profitA], [profitB]])

dualResult = linprog(b, A_ub=-A.transpose(), b_ub=-c.transpose(), method='highs')
print(f"Dual problem {dualResult.x}, with profit of {round(dualResult.fun)}")
print("Invest 100 hours in station 1 because highest shadow price of 150")


# Increse TV B price
beginingOptimal = linprog(-c.flatten(), A_ub=A, b_ub=b.flatten(), method='highs').x
currentOptimal = beginingOptimal
change = 1
while beginingOptimal[0] == currentOptimal[0]:
    c = np.matrix([[profitA], [profitB + change]])
    currentOptimal = linprog(-c.flatten(), A_ub=A, b_ub=b.flatten(), method='highs').x
    change += 1

print(f"\nThr price of B has to increse by {change - 1} to change the optimal solution from {beginingOptimal} to {currentOptimal}")



# TV C
A = np.matrix([[stage1A, stage1B, stage1C], [stage2A, stage2B, stage2C], [stage3ABC, stage3ABC, stage3ABC]])
b = np.matrix([[totTime1], [totTime2], [totTime3]])
c = np.matrix([[profitA], [profitB], [profitC]])

# Calculate with producing TV C
print("It is worth it to produce TV C")
print(f"Reduced cost of producing C {profitC - (150 * stage1C + 0 * stage2C + 125 * stage3ABC)}")
result = linprog(-c.flatten(), A_ub=A, b_ub=b.flatten(), method='highs')
print(f"\nOptimal solution with TV C {result.x}, with profit of {-result.fun}")


# Extra time in quality
inspectionA = 0.5
inspectionB = 0.75
inspectionC = 0.1

hoursAdded = result.x[0] * inspectionA + result.x[1] * inspectionB + result.x[2] * inspectionC
print(f"\nHours added in quality inspection: {hoursAdded}")
