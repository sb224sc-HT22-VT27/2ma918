import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull, convex_hull_plot_2d
from scipy.optimize import linprog

profitA = 700
profitB = 1000

stage1A = 3
stage1B = 5
totTime1 = 3900

stage2A = 1
stage2B = 3
totTime2 = 2100

stage3AB = 2
totTime3 = 2200

A = np.matrix([[stage1A, stage1B], [stage2A, stage2B], [stage3AB, stage3AB]])
b = np.matrix([[totTime1], [totTime2], [totTime3]])
c = np.matrix([[profitA], [profitB]])

x = np.linspace(0, 1200, 100)

y1 = ((b[0].item() - A[0,0].item()*x) / A[0,1].item())
y2 = ((b[1].item() - A[1,0].item()*x) / A[1,1].item())
y3 = ((b[2].item() - A[2,0].item()*x) / A[2,1].item())
plt.plot(x, y1, label="Stage 1")
plt.plot(x, y2, label="Stage 2")
plt.plot(x, y3, label="Stage 3")

plt.xlabel("TV A")
plt.ylabel("TV B")
plt.ylim(0, 1200)
plt.legend()

# Plot convex hull and level curves
vertices = np.array([[0,0], [0,700], [300,600], [800,300], [1100,0]])
convex_hull_plot_2d(ConvexHull(vertices))
plt.ylim(0, 800)

C_values = [k * 10**5 for k in range(1, 9)]
for k, C in enumerate(C_values, 1):
    y_k = (C - c[0, 0] * x) / c[1, 0] 
    plt.plot(x, y_k, 'r', alpha=k/8)

# Determine max vertex
max = 0
maxVertex = vertices[0]
for i in range(len(vertices)):
    value = (c.transpose() @ vertices[i]).item()
    if value > max:
        max = value
        maxVertex = vertices[i]

print(f"Optimal solution manual caluclation {maxVertex}, with profit of {max}")

# Find result with scipy
result = linprog(-c.flatten(), A_ub=A, b_ub=b.flatten(), method='highs')
print(f"Optimal solution scipy caluclation {result.x}, with profit of {-result.fun}")

# Find results with slack variables
A_aug = np.hstack((A, np.eye(3)))
c_aug = np.vstack((-c, np.array([[0],[0],[0]])))

result_standard = linprog(c_aug, A_eq=A_aug, b_eq=b, bounds=(0, None), method='highs')
print(f"Optimal solution slack variables {result_standard.x}, with profit of {-result_standard.fun}")

plt.show()
