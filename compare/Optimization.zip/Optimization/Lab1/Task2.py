import numpy as np
from numpy.random import rand, randn
from scipy.optimize import linprog
from time import perf_counter

print("The b vector is the one vector which means we have a feasible solution meaning that the slack varaibles are > 0 which is a feasible solution\n")

# Simplex
simplexAverage = 0
i = 10
while (simplexAverage < 1000):
    simplexAverage = 0
    for j in range(5):
        n = i # Freely changed
        A = np.concatenate([rand(n, n) + 1, np.eye(n)], axis = -1)
        b = np.ones(n)
        c = np.concatenate([randn(n), np.zeros(n)])


        start_time = perf_counter()
        result = linprog(-c, A_eq=A, b_eq=b, method='simplex', options={'maxiter': 5000})
        elapsed_time = 1000 * (perf_counter()-start_time)

        simplexAverage += elapsed_time

    simplexAverage /= 5
    print(f"Simplex {i}: {simplexAverage}")
    i += 10

simplexBest = i - 10

# HiGHS
highsAverage = 0
i = 100
while (highsAverage < 1000):
    highsAverage = 0
    for j in range(5):
        n = i # Freely changed
        A = np.concatenate([rand(n, n) + 1, np.eye(n)], axis = -1)
        b = np.ones(n)
        c = np.concatenate([randn(n), np.zeros(n)])


        start_time = perf_counter()
        result = linprog(-c, A_eq=A, b_eq=b, options={'maxiter': 5000})
        elapsed_time = 1000 * (perf_counter()-start_time)

        highsAverage += elapsed_time

    highsAverage /= 5
    print(f"Highs {i}: {highsAverage}")
    i += 100
highsBest = i - 100


print(f"Simplex one second: {simplexBest}")
print(f"Highs one second: {highsBest}")
