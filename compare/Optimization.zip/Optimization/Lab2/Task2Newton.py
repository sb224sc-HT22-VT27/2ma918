import numpy as np

def gradient(x):
    return np.array([2*x[0]+2-x[1], 6*x[1]-30-x[0]])

def hessian_inv():
    return np.array([[6/11, 1/11], [1/11, 2/11]])

def newton(x):
    i = 0

    while np.linalg.norm(gradient(x)) >= 0.001: 
        i += 1
        x = x - hessian_inv()@gradient(x)
    return x, i

x, i = newton(np.array([1, 1]))
print(f"Calculated value Newton: {x}")
print(f"Number of iterations: {i}")

