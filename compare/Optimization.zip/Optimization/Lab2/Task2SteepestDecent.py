import numpy as np

def fValue(x):
    return (x[0] + 1)**2 - x[0]*x[1] + 3*(x[1] - 5)**2


def gradient(x):
    return np.array([2*x[0]+2-x[1], 6*x[1]-30-x[0]])


def armijo(x):
    t = 1
    grad = gradient(x)
    w = x - t*grad

    if fValue(w) <= fValue(x) - 0.2 * t * (grad@grad):
        while fValue(w) <= fValue(x) - 0.2 * t * (grad@grad):
            t = 2 * t
            w = x - t*grad
        t = t / 2
        w = x - t*grad
    else:
        while fValue(w) > fValue(x) - 0.2 * t * (grad@grad):
            t = t / 2
            w = x - t*grad

    return x - t*grad


def SteepestDecent(x):
    i = 0
    while ((gradient(x)[0]**2 + gradient(x)[1]**2)**0.5 >= 0.001):
        i+=1
        x = armijo(x)
    return x, i


x, i = SteepestDecent(np.array([-1, 1.5]))
print(f"Calculated value Steepest Decent: {x}")
print(f"Number of iterations: {i}")
