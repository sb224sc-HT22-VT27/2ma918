import numpy as np
from scipy.optimize import linprog

A = np.matrix([[-1, -1, -1, 0, 0, 0, 0, 0, 0], 
               [0, 0, 0, -1, 0, 0, 1, 0, 0],
               [1, 0, 0, 0, -1, -1, 0, 0, 0],
               [0, 1, 0, 0, 0, 0, -1, 0, 0],
               [0, 0, 0, 1, 1, 0, 0, -1, 0],
               [0, 0, 0, 0, 0, 0, 0, 1, -1],
               [0, 0, 1, 0, 0, 1, 0, 0, 1]])

cost = [18,24,62,51,31,46,29,42,20]
supplyDemand = [-2500,-1000,0,0,1000,500,2000]

capacity = [1000,1000,1000,2000,500,1000,1000,500,2000]
bounds = [(0, cap) for cap in capacity]

result = linprog(cost, A_eq=A, b_eq=supplyDemand, bounds=bounds, method='highs')
print(f"Minimum cost flow {result.x}, with total cost of {result.fun}")

# Introducing Värnamo
A = np.matrix([[-1,-1,0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0,0,-1, -1, -1, 0, 0, 0, 0, 0, 0], 
               [0,0,0, 0, 0, -1, 0, 0, 1, 0, 0],
               [0,0,1, 0, 0, 0, -1, -1, 0, 0, 0],
               [0,0,0, 1, 0, 0, 0, 0, -1, 0, 0],
               [1,0,0, 0, 0, 1, 1, 0, 0, -1, 0],
               [0,1,0, 0, 0, 0, 0, 0, 0, 1, -1],
               [0,0,0, 0, 1, 0, 0, 1, 0, 0, 1]])

cost = [43,50,18,24,62,51,31,46,29,42,20]
supplyDemand = [-750,-2000,-750,0,0,1000,500,2000]

capacity = [2000,500,1000,1000,1000,2000,500,1000,1000,500,2000]
bounds = [(0, cap) for cap in capacity]

result = linprog(cost, A_eq=A, b_eq=supplyDemand, bounds=bounds, method='highs')
print(f"Minimum cost flow adding Värnamo {result.x}, with total cost of {result.fun}")


# Introducing Vislanda
A = np.matrix([[-1,-1,0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0,0,-1, -1, -1, 0, 0, 0, 0, 0, 0], 
               [0,0,0, 0, 0, -1, 0, 0, 1, 0, 0],
               [0,0,1, 0, 0, 0, -1, -1, 0, 0, 0],
               [0,0,0, 1, 0, 0, 0, 0, -1, 0, 0],
               [0,0,0, 0, 0, 1, 1, 0, 0, -1, 0],
               [1,0,0, 0, 0, 0, 0, 0, 0, 1, -1],
               [0,1,0, 0, 1, 0, 0, 1, 0, 0, 1]])

cost = [15,29,18,24,62,51,31,46,29,42,20]
supplyDemand = [-380,-2120,-1000,0,0,1000,500,2000]

capacity = [500,500,1000,1000,1000,2000,500,1000,1000,500,2000]
bounds = [(0, cap) for cap in capacity]

result = linprog(cost, A_eq=A, b_eq=supplyDemand, bounds=bounds, method='highs')
print(f"Minimum cost flow adding Vislanda {result.x}, with total cost of {result.fun}")
