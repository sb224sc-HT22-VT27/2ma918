import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from scipy.optimize import minimize

def rosenbrock(x):
    return (1 - x[0])**2 + 100*(x[1] - x[0]**2)**2


def rosenbrockGradient(x):
    return np.array([-2 + 2*x[0] - 400*x[0]*x[1] + 400*x[0]**3, 200*(x[1] - x[0]**2)])


def armijo(x):
    t = 1
    grad = rosenbrockGradient(x)
    w = x - t*grad

    if rosenbrock(w) <= rosenbrock(x) - 0.2 * t * (grad@grad):
        while rosenbrock(w) <= rosenbrock(x) - 0.2 * t * (grad@grad):
            t = 2 * t
            w = x - t*grad
        t = t / 2
        w = x - t*grad
    else:
        while rosenbrock(w) > rosenbrock(x) - 0.2 * t * (grad@grad):
            t = t / 2
            w = x - t*grad

    return x - t*grad


def SteepestDecent(x):
    xHistory = [x]
    i = 0
    while ((rosenbrockGradient(x)[0]**2 + rosenbrockGradient(x)[1]**2)**0.5 >= 0.0001):
        i+=1
        x = armijo(x)
        xHistory.append(x)
    return xHistory, i


def hessian_inv(x):
    hess = np.array([[1200*x[0]**2 - 400*x[1] + 2, -400 * x[0]], [-400 * x[0], 200]])
    determinant = np.linalg.det(hess)
    return np.array([[hess[1][1], -hess[0][1]], [-hess[0][1], hess[0][0]]]) / determinant

def newton(x):
    xHistory = [x]
    i = 0

    while np.linalg.norm(rosenbrockGradient(x)) >= 0.001: 
        i += 1
        x = x - hessian_inv(x)@rosenbrockGradient(x)
        xHistory.append(x)
    return xHistory, i


x = np.linspace(-2, 2, 1000)
y = np.linspace(-1, 3, 1000)
[X, Y] = np.meshgrid(x, y)
Z = rosenbrock([X, Y])

# plt.figure(1)
# plt.contourf(X, Y, Z, 50, cmap=cm.jet)
# plt.title('Rosenbrock')
# plt.colorbar()

# plt.figure(2)
# plt.contourf(X ,Y, np.log(Z), 50, cmap=cm.jet)
# plt.title('Rosenbrock (log)')
# plt.colorbar()

plt.figure(3)
plt.contourf(X, Y, np.log(Z), 50, cmap=cm.jet)
plt.colorbar()
ps, i = SteepestDecent(np.array([-1, 1.5]))
px = np.array([p[0] for p in ps])
py = np.array([p[1] for p in ps])
plt.title(f'Steepest Descent, {i} iterations')
plt.plot(px, py)
plt.plot(px[0], py[0], 'o', color='black') # Starting point
plt.plot(px[-1], py[-1], 'o', color='white') # End point
plt.xlim(-2, 2)
plt.ylim(-1 ,3)

plt.figure(4)
plt.contourf(X, Y, np.log(Z), 50, cmap=cm.jet)
plt.colorbar()
ps, i = newton(np.array([-1, 1.5]))
px = np.array([p[0] for p in ps])
py = np.array([p[1] for p in ps])
plt.title(f'Newton, {i} iterations')
plt.plot(px, py)
plt.plot(px[0], py[0], 'o', color='black') # Starting point
plt.plot(px[-1], py[-1], 'o', color='white') # End point
plt.xlim(-2, 2)
plt.ylim(-1 ,3)

plt.show()

res = minimize(rosenbrock, [-1, 1.5])
print(res.x)
